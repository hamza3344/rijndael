﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace rijndaelalgo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string en = encrypt("1234567890123456", textBox1.Text);
            Clipboard.SetText(en);
            MessageBox.Show(en);
        }
       public static string encrypt(string key,string plaintext)
        {
            byte[] iv = new byte[16];//16 means lenght of key is 16
            using(Rijndael rij=Rijndael.Create())
            {
                rij.Key = Encoding.UTF8.GetBytes(key);
                rij.IV = iv;
                ICryptoTransform encryptor = rij.CreateEncryptor(rij.Key, rij.IV);
                var ms = new MemoryStream();
                var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write);
                byte[] input = Encoding.UTF8.GetBytes(plaintext);
                cs.Write(input, 0, input.Length);
                cs.FlushFinalBlock();
                return Convert.ToBase64String(ms.ToArray());
            }
        }
        public static string Decrypt(string key, string CipherText)
        {
            byte[] iv = new byte[16];//16 means lenght of key is 16
            byte[] buffer = Convert.FromBase64String(CipherText);
            using (Rijndael rij = Rijndael.Create())
            {
                rij.Key = Encoding.UTF8.GetBytes(key);
                rij.IV = iv;
                ICryptoTransform encryptor = rij.CreateDecryptor(rij.Key, rij.IV);
                var ms = new MemoryStream();
                var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write);
                cs.Write(buffer, 0, buffer.Length);
                cs.FlushFinalBlock();
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string de = Decrypt("1234567890123456", textBox2.Text);
            Clipboard.SetText(de);
            MessageBox.Show(de);
        }
    }
}
